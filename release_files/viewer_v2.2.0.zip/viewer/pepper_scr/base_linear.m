a = 5
f = a*x
