function handles = gcbo

h = get(0, 'CallbackObject');
