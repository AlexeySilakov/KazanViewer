f = a*lshape(x, xo, fwhh, 1)*1e6
a = 1
xo = 3622
fwhh = 33
