fft.awin = 'exp'
fft.awidth = 0.6
fft.aalpha = 1.9
fft.ashift = 0
fft.zerofill = 2.1
fft.rshift = 0
fft.lshift = 0
fft.phase0 = 0
