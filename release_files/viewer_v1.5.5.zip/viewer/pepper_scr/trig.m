% default script for powderbox plugin
Sys.S = 0.5
Sys.g(1) = 2
Sys.g(2) = 2
Sys.g(3) = 2
Sys.lw = 1
Exp.mwFreq = 34
%Exp.Harmonic = 1