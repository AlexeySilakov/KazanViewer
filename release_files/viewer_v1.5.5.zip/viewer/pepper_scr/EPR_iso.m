% default script for pepper
Sys.S = 0.5
Sys.g(1:3) = 2
Sys.lw = 1
Exp.mwFreq = 9.77
Exp.Harmonic = 1
Opt.Sim = 'pepper'
