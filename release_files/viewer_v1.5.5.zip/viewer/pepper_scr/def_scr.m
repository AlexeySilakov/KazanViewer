% default script for powderbox plugin
Sys.S = 0.5
Sys.g(1) = 2
Sys.g(2) = 2
Sys.g(3) = 2
Sys.lw = 1
Sys.gStrain(1) = 0
Sys.gStrain(2) = 0
Sys.gStrain(3) = 0
Exp.mwFreq = 9.77
%Exp.Harmonic = 1