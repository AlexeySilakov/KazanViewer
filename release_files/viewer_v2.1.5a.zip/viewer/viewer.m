function viewer()

kazan;
