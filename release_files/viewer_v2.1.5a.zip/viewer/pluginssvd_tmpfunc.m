function dy = svd_tmpfunc(t, y) 
global k0 k12 k23; 
